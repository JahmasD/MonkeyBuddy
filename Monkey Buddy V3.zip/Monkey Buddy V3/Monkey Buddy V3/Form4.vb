﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim myform As New Form5
        myform.Show()

    End Sub
End Class