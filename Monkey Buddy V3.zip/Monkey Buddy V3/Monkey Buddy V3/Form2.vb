﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()

        Dim myform As New Form3
        myform.Show()

    End Sub


    Dim RandomShit As New Random
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If DesktopLocation = New Point(RandomShit.Next(1, 1600), RandomShit.Next(1, 500)) Then
            DesktopLocation = New Point(RandomShit.Next(1, 1600), RandomShit.Next(1, 500))
        Else
            DesktopLocation = New Point(RandomShit.Next(1, 1600), RandomShit.Next(1, 500))
        End If
    End Sub
End Class
